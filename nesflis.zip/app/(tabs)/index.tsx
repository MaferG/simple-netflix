import {
  Image,
  StyleSheet,
  Platform,
  View,
  Text,
  Modal,
  Dimensions,
  Button,
} from "react-native";
import { HelloWave } from "@/components/HelloWave";
import ParallaxScrollView from "@/components/ParallaxScrollView";
import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { useEffect, useState } from "react";
import { api, TOKEN, API_URL } from "../../api/api";
import PagerView from "react-native-pager-view";

export default function HomeScreen() {
  const [data, setData] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await api.get(
          `movie/now_playing?language=en-US&page=1`,
          {
            headers: {
              Authorization: `Bearer ${TOKEN}`,
            },
          }
        );
        setData(response.data.results.slice(5));
        console.log(JSON.stringify(response.data.results.slice(10)));
      } catch (error) {
        console.log(error);
      }
    };

    fetchData();
  }, []);
  const [modalVisible, setModalVisible] = useState(false);

  const openModal = () => {
    setModalVisible(true);
  };

  const closeModal = () => {
    setModalVisible(false);
  };
  return (
    <>
      <ParallaxScrollView
        headerBackgroundColor={{ light: "#A1CEDC", dark: "#1D3D47" }}
      >
        <ThemedView style={styles.stepContainer}>
          <ThemedText type="subtitle">Tv shows</ThemedText>
          <ThemedText type="subtitle">Movies</ThemedText>
          <ThemedText type="subtitle">Categories</ThemedText>
          <Image
            source={require("@/assets/images/user.png")}
            style={styles.reactLogo}
          />
          <ThemedText type="subtitle">Now Playing</ThemedText>
          <View style={styles.container}>
            <PagerView style={styles.container} initialPage={0}>
              {data.map((item) => (
                <View style={styles.page} key="1">
                  <ThemedText>{item.original_title}</ThemedText>
                  <Image
                    source={{
                      uri: `https://image.tmdb.org/t/p/original${item.poster_path}`,
                    }}
                    style={styles.reactLogo}
                  />
                </View>
              ))}
            </PagerView>
          </View>
          <ThemedText type="subtitle">Categoria</ThemedText>
          <View style={styles.container}>
            <PagerView style={styles.container} initialPage={0}>
              {data.map((item) => (
                <View style={styles.page} key="1">
                  <ThemedText>{item.original_title}</ThemedText>
                  <Image
                    source={{
                      uri: `https://image.tmdb.org/t/p/original${item.poster_path}`,
                    }}
                    style={styles.reactLogo}
                  />
                </View>
              ))}
            </PagerView>
          </View>
          <ThemedText type="subtitle">Categoria</ThemedText>
          <View style={styles.container}>
            <PagerView style={styles.container} initialPage={0}>
              {data.map((item) => (
                <View style={styles.page} key="1">
                  <ThemedText>{item.original_title}</ThemedText>
                  <Image
                    source={{
                      uri: `https://image.tmdb.org/t/p/original${item.poster_path}`,
                    }}
                    style={styles.reactLogo}
                  />
                </View>
              ))}
            </PagerView>
          </View>
        </ThemedView>
        <Modal
          visible={modalVisible}
          animationType="slide"
          transparent={true}
          onRequestClose={closeModal}
        >
          <View style={styles.modalContainer}>
            <View style={styles.modalContent}>
              <Text>This is a modal!</Text>

              <Button title="Close Modal" onPress={closeModal} />
            </View>
          </View>
        </Modal>
      </ParallaxScrollView>
    </>
    /* <ThemedView style={styles.stepContainer}>
        <ThemedText type="subtitle">Step 1: Try it</ThemedText>
        <ThemedText>
          Edit <ThemedText type="defaultSemiBold">app/(tabs)/index.tsx</ThemedText> to see changes.
          Press{' '}
          <ThemedText type="defaultSemiBold">
            {Platform.select({ ios: 'cmd + d', android: 'cmd + m' })}
          </ThemedText>{' '}
          to open developer tools.
        </ThemedText>
      </ThemedView>
      <ThemedView style={styles.stepContainer}>
        <ThemedText type="subtitle">Step 2: Explore</ThemedText>
        <ThemedText>
          Tap the Explore tab to learn more about what's included in this starter app.
        </ThemedText>
      </ThemedView>
      <ThemedView style={styles.stepContainer}>
        <ThemedText type="subtitle">Step 3: Get a fresh start</ThemedText>
        <ThemedText>
          When you're ready, run{' '}
          <ThemedText type="defaultSemiBold">npm run reset-project</ThemedText> to get a fresh{' '}
          <ThemedText type="defaultSemiBold">app</ThemedText> directory. This will move the current{' '}
          <ThemedText type="defaultSemiBold">app</ThemedText> to{' '}
          <ThemedText type="defaultSemiBold">app-example</ThemedText>.
        </ThemedText>
      </ThemedView>
*/
  );
}

const styles = StyleSheet.create({
  titleContainer: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  stepContainer: {
    gap: 8,
    marginBottom: 8,
  },
  reactLogo: {
    height: 150,
    width: 150,
    left: 10,
    top: 10,
  },
  container: {
    flex: 1,
    height: 200,
  },
  page: {
    justifyContent: "center",
    alignItems: "center",
  },
  modalContainer: {
    flex: 1,
    justifyContent: "flex-end",
    alignItems: "center",
    backgroundColor: "rgba(0, 0, 0, 0.5)",
  },
  modalContent: {
    backgroundColor: "white",
    width: "100%",
    height: Dimensions.get("window").height * 0.25,
    padding: 20,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  },
});
